// UserApi.js
import axios from 'axios';
const API_BASE_URI = 'http://localhost:3005';
export const saveUser = async (userData) => {
    try {
        // Implement save user logic here
    } catch (error) {
        console.error(error);
    }
};
export const getUserById = async (userId) => {
    try {
        const response = await axios.get(`${API_BASE_URI}/users/${userId}`);
        return response.data;
    } catch (error) {
        console.error(error);
    }
};
export const updateUser = async (userId, updatedUserData) => {
    try {
        // Implement update user logic here
    } catch (error) {
        console.error(error);
    }
};
export const deleteUser = async (userId) => {
    try {
        await axios.delete(`${API_BASE_URI}/users/${userId}`);
    } catch (error) {
        console.error(error);
    }
};