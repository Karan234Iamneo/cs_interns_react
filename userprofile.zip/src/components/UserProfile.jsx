import React, { useEffect, useState } from 'react';
import { getUserById, deleteUser } from '../services/UserApi';
import { Card, CardContent, CardActions, Button } from '@mui/material';
import { useParams, useNavigate } from 'react-router-dom';

const UserProfile = () => {
    const { id } = useParams();
    const [user, setUser] = useState({});
    const [editMode, setEditMode] = useState(false);
    const navigate = useNavigate();

    useEffect(() => {
        const fetchUserData = async () => {
            const userData = await getUserById(id);
            setUser(userData);
        };
        fetchUserData();
    }, [id]);

    const handleChangeEvent = (e) => {
        setUser({ ...user, [e.target.name]: e.target.value });
    };

    const handleEditClick = () => {
        setEditMode(true);
    };

    const handleSaveClick = async () => {
        // Implement save logic here
        setEditMode(false);
    };

    const handleDeleteClick = async () => {
        await deleteUser(id);
        navigate('/'); // Assuming this path leads to the homepage
    };

    return (
        <Card>
            <CardContent>
                {editMode ? (
                    <div>
                        <input type="text" name="name" value={user.name} onChange={handleChangeEvent} />
                        <input type="email" name="email" value={user.email} onChange={handleChangeEvent} />
                        <input type="tel" name="phone" value={user.phone} onChange={handleChangeEvent} />
                        <Button onClick={handleSaveClick}>Save</Button>
                    </div>
                ) : (
                    <div>
                        <p>Name: {user.name}</p>
                        <p>Email: {user.email}</p>
                        <p>Phone: {user.phone}</p>
                        <Button onClick={handleEditClick}>Edit</Button>
                        <Button onClick={handleDeleteClick}>Delete</Button>
                    </div>
                )}
            </CardContent>
            <CardActions>
                {/* Add any additional actions here */}
            </CardActions>
        </Card>
    );
};

export default UserProfile;