import React, { useState } from 'react';
// import './Form.css';
import { saveUser } from '../services/UserApi';
import { useNavigate } from 'react-router-dom';

const UserForm = () => {
    const [formData, setFormData] = useState({ name: '', email: '', phone: '' });
    const navigate = useNavigate();

    const handleChangeEvent = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        await saveUser(formData);
        navigate('/user-profile'); // Assuming this path leads to the user profile page
    };

    return (
        <div>
            <form onSubmit={handleSubmit}>
                <label>Name:</label>
                <input type="text" name="name" value={formData.name} onChange={handleChangeEvent} />
                <label>Email:</label>
                <input type="email" name="email" value={formData.email} onChange={handleChangeEvent} />
                <label>Phone:</label>
                <input type="tel" name="phone" value={formData.phone} onChange={handleChangeEvent} />
                <button type="submit">Submit</button>
            </form>
        </div>
    );
};

export default UserForm;