import React, { useState } from 'react';
import TodoForm from './TodoForm';
import TodoItem from './TodoItem';

function TodoList() {
    const [todos, setTodos] = useState([]);
    const [idCount, setIdCount] = useState(1);

    function addTodo(text) {
        setTodos([...todos, { id: idCount, text, isComplete: false }]);
        setIdCount(idCount + 1);
    }

    function editTodo(id, newText) {
        setTodos(todos.map(todo => todo.id === id ? { ...todo, text: newText } : todo));
    }

    function toggleComplete(id) {
        setTodos(todos.map(todo => todo.id === id ? { ...todo, isComplete: !todo.isComplete } : todo));
    }

    function deleteTodo(id) {
        setTodos(todos.filter(todo => todo.id !== id));
    }

    function clearCompleted() {
        setTodos(todos.filter(todo => !todo.isComplete));
    }

    return (
        <div>
            <h1>To-do Catalog</h1>
            <TodoForm addTodo={addTodo} />
            {todos.map(todo => (
                <TodoItem key={todo.id} todo={todo} editTodo={editTodo} toggleComplete={toggleComplete} deleteTodo={deleteTodo} />
            ))}
            <button onClick={clearCompleted}>Clear Completed</button>
        </div>
    );
}

export default TodoList;