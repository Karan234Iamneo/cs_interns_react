import React, { useState } from 'react';

function TodoForm({ addTodo }) {
    const [inputValue, setInputValue] = useState('');

    function handleInputChange(e) {
        setInputValue(e.target.value);
    }

    function handleAddTodo() {
        if (inputValue.trim() !== '') {
            addTodo(inputValue);
            setInputValue('');
        }
    }

    return (
        <div>
            <input type="text" value={inputValue} onChange={handleInputChange} />
            <button onClick={handleAddTodo}>Add</button>
        </div>
    );
}

export default TodoForm;