import React, { useState } from 'react';

function TodoItem({ todo, editTodo, toggleComplete, deleteTodo }) {
    const [editedText, setEditedText] = useState(todo.text);

    function handleEdit(e) {
        setEditedText(e.target.value);
        editTodo(todo.id, e.target.value);
    }

    return (
        <div role="listitem">
            <input 
                type="text" 
                value={editedText} 
                onChange={handleEdit} 
            />
            <input 
                type="checkbox" 
                checked={todo.isComplete} 
                onChange={() => toggleComplete(todo.id)} 
            />
            <button onClick={() => deleteTodo(todo.id)}>Delete</button>
        </div>
    );
}

export default TodoItem;